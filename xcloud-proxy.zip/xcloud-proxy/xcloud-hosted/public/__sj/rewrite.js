/*
 * Shared rewriting core. Loaded by the service worker (importScripts),
 * by proxied pages (<script>), and by the Node server (require).
 *
 * URL scheme: a target URL is proxied as  <proxy-origin>/p/<absolute target URL>
 * e.g. /p/https://example.com/a/b?c=1. Because the target URL is left
 * unencoded, relative URLs inside a page resolve to proxied URLs for free.
 */
(function (root) {
  'use strict';

  const PREFIX = '/p/';

  // ---------------------------------------------------------------- URLs

  // The proxy's own origin (undefined on the server).
  const PROXY_ORIGIN = root.location && root.location.origin;

  function encodeUrl(url, base) {
    const s = String(url);
    if (s.startsWith(PREFIX + 'http')) return s; // already proxied
    let u;
    try { u = new URL(s, base); } catch { return s; }
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return s; // data:, blob:, mailto:, ...
    if (PROXY_ORIGIN && u.origin === PROXY_ORIGIN) {
      // Built against the proxy's address (e.g. new URL('/x', import.meta.url)).
      const rest = u.pathname + u.search + u.hash;
      if (rest.startsWith(PREFIX)) return rest;
      try { u = new URL(rest, new URL(base).origin); } catch { return s; }
    }
    return PREFIX + u.href;
  }

  // Returns the target URL string for a proxied URL, or null if it isn't one.
  function decode(str, origin) {
    let s = String(str);
    if (origin && s.startsWith(origin + PREFIX)) s = s.slice(origin.length);
    if (s.startsWith(PREFIX)) {
      const rest = s.slice(PREFIX.length);
      if (/^https?:\/\//i.test(rest)) return rest;
    }
    return null;
  }

  const URL_ATTRS = new Set(['href', 'src', 'action', 'formaction', 'poster', 'background', 'manifest', 'xlink:href']);
  function isUrlAttr(tag, attr) {
    return URL_ATTRS.has(attr) || (attr === 'data' && tag === 'object');
  }

  function rewriteUrlAttr(value, base) {
    const v = String(value).trim();
    if (!v || v[0] === '#') return String(value);
    if (/^javascript:/i.test(v)) return 'javascript:' + rewriteJs(v.slice(11));
    return encodeUrl(v, base);
  }

  function rewriteSrcset(value, base) {
    const s = String(value);
    const out = [];
    let i = 0;
    while (i < s.length) {
      while (i < s.length && /[\s,]/.test(s[i])) i++;
      if (i >= s.length) break;
      let j = i;
      while (j < s.length && !/\s/.test(s[j])) j++;
      let url = s.slice(i, j);
      let desc = '';
      if (url.endsWith(',')) {
        url = url.replace(/,+$/, '');
      } else {
        let k = j;
        while (k < s.length && s[k] !== ',') k++;
        desc = s.slice(j, k).trim();
        j = k;
      }
      out.push(encodeUrl(url, base) + (desc ? ' ' + desc : ''));
      i = j;
    }
    return out.join(', ');
  }

  // ---------------------------------------------------------------- JS
  // A small tokenizer that skips strings, comments, template literals and
  // regex literals, and renames the identifiers below. Renaming is
  // consistent across a file, so local variables keep working; global and
  // member access goes through Object.prototype accessors (see install())
  // that answer for windows/documents and forward to the real property for
  // every other object (so `el.style.top`, `node.parent` still work).
  // Object-literal keys keep their names; shorthand `{top}` becomes
  // `{top: __sjTop}`, which is right for both literals and destructuring.

  const RENAME = { location: '__sjLocation', top: '__sjTop', parent: '__sjParent', frameElement: '__sjFrameElement' };
  const RENAME_WORDS = Object.keys(RENAME);
  const REGEX_AFTER_KW = new Set(['return', 'typeof', 'instanceof', 'in', 'of', 'new', 'delete', 'void',
    'throw', 'case', 'do', 'else', 'yield', 'await', 'extends']);
  const END_MODULE_CLAUSE = new Set(['class', 'function', 'const', 'let', 'var', 'default', 'async']);

  function idStart(c) { return (c >= 97 && c <= 122) || (c >= 65 && c <= 90) || c === 36 || c === 95 || c === 92 || c >= 128; }
  function idPart(c) { return idStart(c) || (c >= 48 && c <= 57); }
  function isWs(c) { return c === 32 || c === 9 || c === 10 || c === 13 || c === 11 || c === 12 || c === 0xa0 || c === 0xfeff || c === 0x2028 || c === 0x2029; }

  function rewriteJs(input) {
    const src = String(input);
    if (!RENAME_WORDS.some((w) => src.indexOf(w) !== -1)) return src;
    const n = src.length;
    const hits = []; // [pos, len, replacement]
    // Open brackets: 0 = brace, 1 = template substitution, 2 = import/export
    // clause braces, 3 = paren/bracket.
    const stack = [];
    let i = 0, last = '', lastType = '', moduleClause = false;

    function scanString(j, q) {
      j++;
      while (j < n) {
        const c = src.charCodeAt(j);
        if (c === 92) j += 2;
        else if (c === q) return j + 1;
        else if (c === 10) return j;
        else j++;
      }
      return n;
    }
    function scanTemplate(j) {
      while (j < n) {
        const c = src.charCodeAt(j);
        if (c === 92) j += 2;
        else if (c === 96) return { end: j + 1, done: true };
        else if (c === 36 && src.charCodeAt(j + 1) === 123) return { end: j + 2, done: false };
        else j++;
      }
      return { end: n, done: true };
    }
    function scanRegex(j) {
      let k = j + 1, inClass = false;
      while (k < n) {
        const ch = src[k];
        if (ch === '\\') { k += 2; continue; }
        if (ch === '\n') return -1;
        if (inClass) { if (ch === ']') inClass = false; }
        else if (ch === '[') inClass = true;
        else if (ch === '/') { k++; break; }
        k++;
      }
      while (k < n && idPart(src.charCodeAt(k))) k++;
      return k;
    }
    function regexOk() {
      if (lastType === '') return true;
      if (lastType === 'punc') return !(last === ')' || last === ']' || last === '}');
      if (lastType === 'id') return REGEX_AFTER_KW.has(last);
      return false;
    }
    function nextNonWs(j) {
      while (j < n && isWs(src.charCodeAt(j))) j++;
      return src[j];
    }

    while (i < n) {
      const c = src.charCodeAt(i);
      if (isWs(c)) { i++; continue; }
      if (c === 47) { // '/'
        const d = src.charCodeAt(i + 1);
        if (d === 47) { const e = src.indexOf('\n', i); i = e < 0 ? n : e; continue; }
        if (d === 42) { const e = src.indexOf('*/', i + 2); i = e < 0 ? n : e + 2; continue; }
        if (regexOk()) {
          const e = scanRegex(i);
          if (e > 0) { i = e; lastType = 'regex'; last = ''; continue; }
        }
        i++; lastType = 'punc'; last = '/'; continue;
      }
      if (c === 34 || c === 39) { i = scanString(i, c); lastType = 'str'; last = ''; continue; }
      if (c === 96) {
        const r = scanTemplate(i + 1);
        i = r.end; if (!r.done) stack.push(1);
        lastType = 'tmpl'; last = ''; continue;
      }
      if (idStart(c)) {
        let j = i + 1;
        while (j < n && idPart(src.charCodeAt(j))) j++;
        const word = src.slice(i, j);
        const afterDot = lastType === 'punc' && last === '.';
        if (!afterDot && (word === 'import' || word === 'export')) moduleClause = true;
        else if (END_MODULE_CLAUSE.has(word)) moduleClause = false;
        const rep = Object.prototype.hasOwnProperty.call(RENAME, word) ? RENAME[word] : null;
        if (rep) {
          const top = stack[stack.length - 1];
          const listStart = lastType === 'punc' && (last === '{' || last === ',');
          const next = listStart ? nextNonWs(j) : '';
          if (top === 2) hits.push([i, word.length, rep]);
          else if (listStart && next === ':') { /* object key: keep */ }
          else if (listStart && top === 0 && (next === '}' || next === ',')) hits.push([i, word.length, word + ': ' + rep]);
          else hits.push([i, word.length, rep]);
        }
        lastType = 'id'; last = word; i = j; continue;
      }
      if ((c >= 48 && c <= 57) || (c === 46 && src.charCodeAt(i + 1) >= 48 && src.charCodeAt(i + 1) <= 57)) {
        let j = i + 1;
        while (j < n) {
          const d = src.charCodeAt(j);
          if (idPart(d) || d === 46) j++;
          else if ((d === 43 || d === 45) && (src[j - 1] === 'e' || src[j - 1] === 'E') && !/^0[xX]/.test(src.slice(i, i + 2))) j++;
          else break;
        }
        lastType = 'num'; last = ''; i = j; continue;
      }
      if (c === 123) { stack.push(moduleClause ? 2 : 0); moduleClause = false; }
      else if (c === 40 || c === 91) { stack.push(3); moduleClause = false; }
      else if (c === 41 || c === 93) stack.pop();
      else if (c === 59 || c === 61) moduleClause = false;
      else if (c === 125) {
        if (stack.pop() === 1) {
          const r = scanTemplate(i + 1);
          i = r.end; if (!r.done) stack.push(1);
          lastType = 'tmpl'; last = ''; continue;
        }
      }
      last = src[i]; lastType = 'punc'; i++;
    }

    if (!hits.length) return src;
    let out = '', prev = 0;
    for (const [pos, len, rep] of hits) { out += src.slice(prev, pos) + rep; prev = pos + len; }
    return out + src.slice(prev);
  }

  // ---------------------------------------------------------------- HTML
  // A forgiving tag scanner (no DOM needed, so it runs in the service worker).

  const RAW_TEXT = new Set(['script', 'style', 'textarea', 'title', 'xmp', 'iframe', 'noembed', 'noframes', 'noscript', 'plaintext']);
  const TAG_RE = /<([a-zA-Z][^\s\/>]*)((?:[^>"']|"[^"]*"|'[^']*')*)>/y;
  const ATTR_RE = /([^\s"'>\/=]+)(\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g;

  function decodeEntities(s) {
    return s.replace(/&(#x[0-9a-f]+|#\d+|amp|quot|apos|lt|gt|nbsp);?/gi, (m, e) => {
      const l = e.toLowerCase();
      if (l[0] === '#') {
        const cp = l[1] === 'x' ? parseInt(l.slice(2), 16) : parseInt(l.slice(1), 10);
        try { return String.fromCodePoint(cp); } catch { return m; }
      }
      return { amp: '&', quot: '"', apos: "'", lt: '<', gt: '>', nbsp: ' ' }[l];
    });
  }
  function escapeAttr(s) { return s.replace(/&/g, '&amp;').replace(/"/g, '&quot;'); }

  function isJsType(t) {
    if (t == null) return true;
    t = t.trim().toLowerCase();
    if (t === '' || t === 'module') return true;
    return /(java|ecma|j|live)script/.test(t) && !t.includes('json');
  }

  function rewriteTag(tag, rawName, attrText, ctx) {
    const attrs = [];
    let m;
    ATTR_RE.lastIndex = 0;
    while ((m = ATTR_RE.exec(attrText))) {
      const hasValue = m[2] != null;
      const raw = hasValue ? (m[3] ?? m[4] ?? m[5] ?? '') : null;
      attrs.push({ name: m[1], lname: m[1].toLowerCase(), raw, text: m[0] });
    }
    const get = (n) => { const a = attrs.find((x) => x.lname === n); return a && a.raw != null ? decodeEntities(a.raw) : null; };

    if (tag === 'meta') {
      const equiv = (get('http-equiv') || '').toLowerCase();
      if (equiv === 'content-security-policy' || equiv === 'content-security-policy-report-only') {
        return { text: '<' + rawName + ' data-sj-disabled-csp="">', js: false };
      }
    }
    if (tag === 'base') {
      const href = get('href');
      if (href != null) { try { ctx.base = new URL(href, ctx.base).href; } catch { /* ignore */ } }
    }

    let changed = false;
    const parts = [];
    for (const a of attrs) {
      let nv = null;
      if (a.lname === 'integrity') { changed = true; continue; }
      if (a.raw != null) {
        const val = decodeEntities(a.raw);
        if (isUrlAttr(tag, a.lname)) nv = rewriteUrlAttr(val, ctx.base);
        else if (a.lname === 'srcset' || a.lname === 'imagesrcset') nv = rewriteSrcset(val, ctx.base);
        else if (a.lname.startsWith('on')) nv = rewriteJs(val);
        else if (tag === 'meta' && a.lname === 'content' && (get('http-equiv') || '').toLowerCase() === 'refresh') {
          const mm = /^(\s*\d*\.?\d*\s*[;,]?\s*(?:url\s*=\s*)?)(['"]?)(.*?)\2\s*$/i.exec(val);
          if (mm && mm[3]) nv = mm[1] + encodeUrl(mm[3], ctx.base);
        }
        if (nv != null && nv !== val) { changed = true; parts.push(' ' + a.name + '="' + escapeAttr(nv) + '"'); continue; }
      }
      parts.push(' ' + a.text);
    }

    const js = tag === 'script' && isJsType(get('type'));
    const module = js && (get('type') || '').trim().toLowerCase() === 'module';
    if (!changed) return { text: '<' + rawName + attrText + '>', js, module };
    const selfClose = /\/\s*$/.test(attrText) ? ' /' : '';
    return { text: '<' + rawName + parts.join('') + selfClose + '>', js, module };
  }

  // opts.inject: markup inserted at the top of <head> (omit for fragments).
  function rewriteHtml(input, base, opts) {
    const html = String(input);
    const ctx = { base };
    const inject = (opts && opts.inject) || '';
    let injected = !inject;
    const out = [];
    const n = html.length;
    let i = 0;

    const copyTo = (str, from) => { const e = html.indexOf(str, from); const end = e === -1 ? n : e + str.length; out.push(html.slice(i, end)); i = end; };

    while (i < n) {
      const lt = html.indexOf('<', i);
      if (lt === -1) { out.push(html.slice(i)); break; }
      out.push(html.slice(i, lt));
      i = lt;
      if (html.startsWith('<!--', i)) { copyTo('-->', i + 4); continue; }
      const next = html[i + 1];
      if (next === '!' || next === '?' || next === '/') { copyTo('>', i); continue; }
      TAG_RE.lastIndex = i;
      const m = TAG_RE.exec(html);
      if (!m) { out.push('<'); i++; continue; }
      const tag = m[1].toLowerCase();
      if (!injected && tag !== 'html' && tag !== 'head') { out.push(inject); injected = true; }
      const res = rewriteTag(tag, m[1], m[2], ctx);
      out.push(res.text);
      i = TAG_RE.lastIndex;
      if (!injected && tag === 'head') { out.push(inject); injected = true; }
      if (RAW_TEXT.has(tag) && !/\/\s*$/.test(m[2])) {
        const close = new RegExp('</' + tag + '(?=[\\s/>])', 'ig');
        close.lastIndex = i;
        const cm = close.exec(html);
        const end = cm ? cm.index : n;
        let body = html.slice(i, end);
        if (tag === 'script' && res.js) {
          const rewritten = rewriteJs(body);
          // React (and others) compare inline script text when hydrating, so
          // the rewritten code first puts the original text back on its
          // element. Module scripts have no currentScript; those keep the
          // rewritten text.
          if (rewritten !== body) {
            body = res.module ? rewritten
              : '__sjRestore(document.currentScript,' + JSON.stringify(body).replace(/</g, '\\u003c') + ');' + rewritten;
          }
        }
        out.push(body);
        i = end;
      }
    }
    if (!injected) out.unshift(inject);
    return out.join('');
  }

  // ---------------------------------------------------------------- cookies
  // Every target cookie is stored on the proxy origin under a name that
  // records its scope:  <name>~h~<host>  (host-only) or  <name>~d~<domain>.

  function cookieKey(name, flag, domain) {
    if (/^__(host|secure)-/i.test(name)) name = '~' + name; // dodge browser prefix rules
    return name + '~' + flag + '~' + domain;
  }
  function parseKey(key) {
    const m = /^(.*)~([hd])~([^~]*)$/.exec(key);
    if (!m) return null;
    let name = m[1];
    if (name.startsWith('~__')) name = name.slice(1);
    return { name, flag: m[2], domain: m[3] };
  }
  function domainMatch(host, k) {
    host = host.toLowerCase();
    return k.flag === 'h' ? host === k.domain : host === k.domain || host.endsWith('.' + k.domain);
  }
  // Proxy-origin Cookie header -> Cookie header for `host`.
  function filterCookies(header, host) {
    const out = [];
    for (const part of String(header || '').split(/;\s*/)) {
      if (!part) continue;
      const eq = part.indexOf('=');
      const key = (eq < 0 ? part : part.slice(0, eq)).trim();
      const k = parseKey(key);
      if (k && domainMatch(host, k)) out.push(k.name + '=' + (eq < 0 ? '' : part.slice(eq + 1)));
    }
    return out.join('; ');
  }
  // Target Set-Cookie -> Set-Cookie for the proxy origin (null = reject).
  function rewriteSetCookie(str, host, secure) {
    const parts = String(str).split(';');
    const first = parts.shift();
    const eq = first.indexOf('=');
    if (eq < 0) return null;
    const name = first.slice(0, eq).trim();
    const value = first.slice(eq + 1);
    if (!name) return null;
    host = host.toLowerCase();
    let domain = null, hadSecure = false;
    const attrs = [];
    for (const p of parts) {
      const t = p.trim();
      const k = t.indexOf('=');
      const an = (k < 0 ? t : t.slice(0, k)).toLowerCase();
      const av = k < 0 ? '' : t.slice(k + 1).trim();
      if (an === 'domain') { if (av) domain = av.replace(/^\./, '').toLowerCase(); }
      else if (an === 'secure') hadSecure = true;
      else if (an === 'expires' || an === 'max-age' || an === 'httponly') attrs.push(t);
    }
    if (domain && !(host === domain || host.endsWith('.' + domain))) return null;
    const key = domain ? cookieKey(name, 'd', domain) : cookieKey(name, 'h', host);
    attrs.push('Path=/', 'SameSite=Lax');
    if (secure && hadSecure) attrs.push('Secure');
    return key + '=' + value + '; ' + attrs.join('; ');
  }

  // ---------------------------------------------------------------- runtime
  // Installs the fake Location for a realm (window or worker). This function
  // is also stringified and prepended to worker scripts, so it must not
  // reference anything outside itself.

  function install(G) {
    if (Object.prototype.hasOwnProperty.call(Object.prototype, '__sjLocation')) return;
    const real = G.location;
    const ORIGIN = real.origin;
    const P = '/p/';
    const cur = () => new URL(real.href.slice(ORIGIN.length + P.length));
    const go = (u, replace) => {
      const abs = new URL(String(u), cur());
      if (abs.protocol === 'javascript:') return;
      const dest = /^https?:$/.test(abs.protocol) ? P + abs.href : abs.href;
      replace ? real.replace(dest) : real.assign(dest);
    };
    const fake = {};
    for (const p of ['href', 'origin', 'protocol', 'host', 'hostname', 'port', 'pathname', 'search', 'hash']) {
      Object.defineProperty(fake, p, {
        enumerable: true,
        get() { return cur()[p]; },
        set: p === 'origin' ? undefined : function (v) {
          if (p === 'href') return go(v);
          if (p === 'hash') { real.hash = v; return; }
          const u = cur(); u[p] = v; go(u.href);
        },
      });
    }
    fake.assign = (u) => go(u);
    fake.replace = (u) => go(u, true);
    fake.reload = () => real.reload();
    fake.toString = () => cur().href;
    fake.valueOf = () => fake;
    fake[Symbol.toPrimitive] = () => cur().href;
    Object.defineProperty(G, '__sj$loc', { value: fake });

    const doc = G.document;
    const NodeC = G.Node;
    // Window, document, and DOM nodes (inline handlers resolve bare names
    // through the element's scope) all answer for this realm.
    const mine = (o) => o === G || (doc && o === doc) || (NodeC && o instanceof NodeC);
    const isWin = (o) => { try { return o != null && o.window === o; } catch { return false; } };
    const winOf = (o) => (isWin(o) ? o : mine(o) ? G : null);
    // The browser UI (shell) and anything cross-origin is outside the page's world.
    const outside = (w) => { try { return !!w.__sjShell || !w.location.href; } catch { return true; } };
    const vParent = (w) => { const p = w.parent; return p === w || outside(p) ? w : p; };
    const vTop = (w) => { let c = w; for (let k = 0; k < 64; k++) { const p = vParent(c); if (p === c) break; c = p; } return c; };

    const define = (name, get, set) => Object.defineProperty(Object.prototype, name, { configurable: true, enumerable: false, get, set });
    define('__sjLocation',
      function () { return mine(this) ? fake : (this == null ? undefined : this.location); },
      function (v) { if (mine(this)) go(v); else this.location = v; });
    // Other windows are wrapped (client.js) so the same-origin policy holds.
    const wrap = (w) => (w !== G && typeof G.__sjWrapWin === 'function' ? G.__sjWrapWin(w) : w);
    define('__sjTop',
      function () { const w = winOf(this); return w ? wrap(vTop(w)) : (this == null ? undefined : this.top); },
      function (v) { if (!winOf(this)) this.top = v; });
    define('__sjParent',
      function () { const w = winOf(this); return w ? wrap(vParent(w)) : (this == null ? undefined : this.parent); },
      function (v) { if (!winOf(this)) this.parent = v; });
    define('__sjFrameElement',
      function () { const w = winOf(this); if (!w) return this == null ? undefined : this.frameElement; return vParent(w) === w ? null : w.frameElement; },
      function (v) { if (!winOf(this)) this.frameElement = v; });
  }

  const SJ = {
    PREFIX, encodeUrl, decode, isUrlAttr, rewriteUrlAttr, rewriteSrcset,
    rewriteJs, rewriteHtml, filterCookies, rewriteSetCookie, install,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = SJ;
  else root.SJ = SJ;
})(typeof self !== 'undefined' ? self : globalThis);
